package io.pact.contact.clients;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.core.model.RequestResponsePact;
import au.com.dius.pact.core.model.annotations.Pact;
import io.pact.contact.models.partyContact;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.HttpClientErrorException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "CustomerProfile")
class partyContactInfoPactTest {
  @Autowired
  private AddressServiceClient AddressServiceClient;

  @Pact(consumer = "partyContactInfo")
  public RequestResponsePact singleCustomer(PactDslWithProvider builder) {
    return builder
      .given("Personal Details exists for customer ID 300", "id", 300)
      .uponReceiving("get contact information for client ID 300")
        .path("/customer/300")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(200)
        .body(
          new PactDslJsonBody()
                  .integerType("id", 300L)
                  .stringType("primaryphonenumber", "(822) 771-2545")
                  .stringType("primaryemailaddress", "tempor@protonmail.net")
                  .stringType("addressline", "1 Main RD")
                  .stringType("state", "Texas")
                  .stringType("postalcode", "56025")
        )
      .toPact();
  }


  @Test
  @PactTestFor(pactMethod = "singleCustomer")
  void testSingleCustomer(MockServer mockServer) {
    AddressServiceClient.setBaseUrl(mockServer.getUrl());
    partyContact partyContact = AddressServiceClient.getCustomerById(300);
    assertThat(partyContact, is(equalTo(new partyContact(300L,"(822) 771-2545","tempor@protonmail.net","1 Main RD","Texas","56025"))));

  }


  @Pact(consumer = "partyContactInfo")
  public RequestResponsePact singleCustomerNotExists(PactDslWithProvider builder) {
    return builder
      .given("Personal Details does not exist for customer ID 400", "id", 400)
      .uponReceiving("get contact information for client ID 400")
        .path("/customer/400")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(404)
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "singleCustomerNotExists")
  void testSingleCustomerNotExists(MockServer mockServer) {
    AddressServiceClient.setBaseUrl(mockServer.getUrl());
    try {
      AddressServiceClient.getCustomerById(400L);
      fail("Expected service call to throw an exception");
    } catch (HttpClientErrorException ex) {
      assertThat(ex.getMessage(), containsString("404 Not Found"));
    }
  }


}
