package io.pact.contact.controllers;

import io.pact.contact.clients.AddressServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class AddressController {
  @Autowired
  private AddressServiceClient addressServiceClient;

  @GetMapping("/customer/{id}")
  public String catalogue(@PathVariable("id") Long id, Model model) {
    System.out.println(addressServiceClient.getCustomerById(id));
    model.addAttribute("customer", addressServiceClient.getCustomerById(id));
    return "details";
  }
}
