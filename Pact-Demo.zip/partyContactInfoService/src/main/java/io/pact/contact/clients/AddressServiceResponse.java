package io.pact.contact.clients;

import io.pact.contact.models.partyContact;
import lombok.Data;

import java.util.List;

@Data
public class AddressServiceResponse {
  private List<partyContact> partyContacts;
}
