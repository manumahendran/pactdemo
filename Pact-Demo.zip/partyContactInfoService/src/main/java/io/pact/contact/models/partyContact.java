package io.pact.contact.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class partyContact {

  private Long id;
  private String primaryphonenumber;
  private String primaryemailaddress;
  private String addressline;
  private String state;
  private String postalcode;
}
