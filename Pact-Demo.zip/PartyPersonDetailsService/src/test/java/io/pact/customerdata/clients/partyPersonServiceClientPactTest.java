package io.pact.customerdata.clients;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.core.model.RequestResponsePact;
import au.com.dius.pact.core.model.annotations.Pact;
import io.pact.customerdata.models.customer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.HttpClientErrorException;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "CustomerProfile")
class partyPersonServiceClientPactTest {
  @Autowired
  private PersonalInfoServiceClient PersonalInfoServiceClient;

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact allCustomers(PactDslWithProvider builder) {
    return builder
      .given("Personal Details exists for all Customers")
        .uponReceiving("get personal details for all Customers")
        .path("/customers")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(200)
        .body(
          new PactDslJsonBody()
            .minArrayLike("customers", 1, 2)
              .integerType("id", 300L)
              .stringType("title", "Mr.")
              .stringType("firstname", "Sharon")
              .stringType("lastname", "Kramer")
              .stringType("birthdate","12/12/2000")
              .closeObject()
            .closeArray()
        )
      .toPact();
  }


  @Test
  @PactTestFor(pactMethod = "allCustomers")
  void testAllCustomers(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    List<customer> customers = PersonalInfoServiceClient.fetchPersonalInfos().getCustomers();
    assertThat(customers, hasSize(2));
    assertThat(customers.get(0), is(equalTo(new customer(300L,"Mr.","Sharon","Kramer","12/12/2000"))));

  }

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact singleCustomer(PactDslWithProvider builder) {
    return builder
      .given("Personal Details exists for customer ID 300", "id", 300)
      .uponReceiving("get information Customer with ID 300")
        .path("/customer/300")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(200)
        .body(
          new PactDslJsonBody()
              .integerType("id", 300L)
              .stringType("title", "Mr.")
              .stringType("firstname", "Sharon")
              .stringType("lastname", "Kramer")
              .stringType("birthdate","12/12/2000")
        )
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "singleCustomer")
  void testSingleCustomer(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    customer customer = PersonalInfoServiceClient.getCustomerById(300);
    assertThat(customer, is(equalTo(new customer(300L,"Mr.","Sharon","Kramer","12/12/2000"))));
  }

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact noCustomers(PactDslWithProvider builder) {
    return builder
      .given("Personal Details for no customers exists")
      .uponReceiving("get information all Customers")
        .path("/customers")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(200)
        .body(
          new PactDslJsonBody().array("customers")
        )
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "noCustomers")
  void testNoCustomers(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    List<customer> customers = PersonalInfoServiceClient.fetchPersonalInfos().getCustomers();
    assertThat(customers, hasSize(0));

  }

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact singleCustomerNotExists(PactDslWithProvider builder) {
    return builder
      .given("Personal Details does not exist for customer with ID 400", "id", 400)
      .uponReceiving("get information for Customer with ID 400")
        .path("/customer/400")
        .matchHeader("Authorization", "Bearer [a-zA-Z0-9=\\+/]+", "Bearer AAABd9yHUjI=")
      .willRespondWith()
        .status(404)
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "singleCustomerNotExists")
  void testSingleCustomerNotExists(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    try {
      PersonalInfoServiceClient.getCustomerById(400L);
      fail("Expected service call to throw an exception");
    } catch (HttpClientErrorException ex) {
      assertThat(ex.getMessage(), containsString("404 Not Found"));
    }
  }

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact noAuthToken(PactDslWithProvider builder) {
    return builder
      .uponReceiving("get information for all Customers with no auth token")
        .path("/customers")
      .willRespondWith()
        .status(401)
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "noAuthToken")
  void testNoAuthToken(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    try {
      PersonalInfoServiceClient.fetchPersonalInfos();
      fail("Expected service call to throw an exception");
    } catch (HttpClientErrorException ex) {
      assertThat(ex.getMessage(), containsString("401 Unauthorized"));
    }
  }

  @Pact(consumer = "PartyPersonDetails")
  public RequestResponsePact noAuthToken2(PactDslWithProvider builder) {
    return builder
      .uponReceiving("get information for Customer by ID with no auth token")
        .path("/customer/400")
      .willRespondWith()
        .status(401)
      .toPact();
  }

  @Test
  @PactTestFor(pactMethod = "noAuthToken2")
  void testNoAuthToken2(MockServer mockServer) {
    PersonalInfoServiceClient.setBaseUrl(mockServer.getUrl());
    try {
      PersonalInfoServiceClient.getCustomerById(400L);
      fail("Expected service call to throw an exception");
    } catch (HttpClientErrorException ex) {
      assertThat(ex.getMessage(), containsString("401 Unauthorized"));
    }
  }
}
