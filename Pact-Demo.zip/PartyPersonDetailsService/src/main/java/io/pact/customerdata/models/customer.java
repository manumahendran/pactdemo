package io.pact.customerdata.models;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class customer {

  private Long id;
  private String title;
  private String firstname;
  private String lastname;
  private String birthdate;
}
