package io.pact.customerdata.models;

import lombok.Data;

import java.util.List;

@Data
public class PersonalInfoList {
  private final String name;
  private final List<customer> customers;
}
