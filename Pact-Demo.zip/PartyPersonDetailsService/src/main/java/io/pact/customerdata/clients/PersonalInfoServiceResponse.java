package io.pact.customerdata.clients;

import io.pact.customerdata.models.customer;
import lombok.Data;

import java.util.List;

@Data
public class PersonalInfoServiceResponse {
  private List<customer> customers;
}
