package io.pact.customerdata.controllers;

import io.pact.customerdata.clients.PersonalInfoServiceClient;
import io.pact.customerdata.models.PersonalInfoList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class PersonalInfoListController {
  @Autowired
  private PersonalInfoServiceClient personalInfoServiceClient;

  @GetMapping("/customerList")
  public String catalogue(Model model) {
    PersonalInfoList customer = new PersonalInfoList("Default Customer List", personalInfoServiceClient.fetchPersonalInfos().getCustomers());
    model.addAttribute("customer", customer);
    return "customer";
  }

  @GetMapping("/customer/{id}")
  public String catalogue(@PathVariable("id") Long id, Model model) {
    System.out.println(personalInfoServiceClient.getCustomerById(id));
    model.addAttribute("customer", personalInfoServiceClient.getCustomerById(id));
    return "details";
  }
}
