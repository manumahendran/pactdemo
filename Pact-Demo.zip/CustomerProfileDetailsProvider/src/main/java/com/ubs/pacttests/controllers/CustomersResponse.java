package com.ubs.pacttests.controllers;

import com.ubs.pacttests.customers.customer;
import lombok.Data;

import java.util.List;

@Data
public class CustomersResponse {
  private final List<customer> customers;
}
