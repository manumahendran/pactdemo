package com.ubs.pacttests.customers;

import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<customer, Long> {

}
