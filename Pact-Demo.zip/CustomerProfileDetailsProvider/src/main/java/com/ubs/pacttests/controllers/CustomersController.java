package com.ubs.pacttests.controllers;

import com.ubs.pacttests.customers.customer;
import com.ubs.pacttests.customers.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CustomersController {
  @ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "customer not found")
  public static class CustomerNotFoundException extends RuntimeException { }

  @Autowired
  private CustomerRepository customerRepository;

  @GetMapping("/customers")
  public CustomersResponse allcustomers() {
    return new CustomersResponse((List<customer>) customerRepository.findAll());
  }

  @GetMapping("/customer/{id}")
  public customer customerById(@PathVariable("id") Long id) {
    return customerRepository.findById(id).orElseThrow(CustomerNotFoundException::new);
  }
}
