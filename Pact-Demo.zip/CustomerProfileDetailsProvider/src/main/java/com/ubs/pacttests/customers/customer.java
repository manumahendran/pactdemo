package com.ubs.pacttests.customers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.stringtemplate.v4.ST;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class customer {
  @Id
  private Long id;
  private String title;
  private String firstname;
  private String lastname;
  private String birthdate;
  private String primaryphonenumber;
  private String primaryemailaddress;
  private String addressline;
  private String state;
  private String postalcode;

}
