package com.ubs.pacttests;

import au.com.dius.pact.provider.junit5.HttpTestTarget;
import au.com.dius.pact.provider.junit5.PactVerificationContext;
import au.com.dius.pact.provider.junit5.PactVerificationInvocationContextProvider;
import au.com.dius.pact.provider.junitsupport.Consumer;
import au.com.dius.pact.provider.junitsupport.Provider;
import au.com.dius.pact.provider.junitsupport.State;
import au.com.dius.pact.provider.junitsupport.loader.PactBroker;
import com.ubs.pacttests.customers.CustomerRepository;
import com.ubs.pacttests.customers.customer;
import org.apache.http.HttpRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestTemplate;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;

import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Provider("CustomerProfile")
@Consumer("partyContactInfo")
@PactBroker(host = "20.7.197.39",port="9292")
//@PactFolder("pacts")

public class partyContactInfoPactTest {

    @LocalServerPort
    private int port;

    @Autowired
    private CustomerRepository customerRepository;


    @BeforeEach
    void setup(PactVerificationContext context) {
        System.setProperty("pact.verifier.publishResults", "true");
        context.setTarget(new HttpTestTarget("localhost", port));
    }

    @TestTemplate
    @ExtendWith(PactVerificationInvocationContextProvider.class)
    void pactVerificationTestTemplate(PactVerificationContext context, HttpRequest request) {
        // WARNING: Do not modify anything else on the request, because you could invalidate the contract
        if (request.containsHeader("Authorization")) {
            request.setHeader("Authorization", "Bearer " + generateToken());
        }
        context.verifyInteraction();
    }

    private static String generateToken() {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putLong(System.currentTimeMillis());
        return Base64.getEncoder().encodeToString(buffer.array());
    }


    @State("Personal Details exists for customer ID 300")
    void custmerExists(Map<String, Object> params) {
        long productId = ((Number) params.get("id")).longValue();
        Optional<customer> product = customerRepository.findById(productId);
        if (!product.isPresent()) {
            customerRepository.save(new customer(productId, "Mr","Allen", "Jennings","12/12/2000","1-254-530-7853","metus.vitae@protonmail.net","8631 A Rd.","Pennsylvania","27413"));
        }
    }



    @State("Personal Details does not exist for customer ID 400")
    void customerNotExists(Map<String, Object> params) {
        long productId = ((Number) params.get("id")).longValue();
        Optional<customer> product = customerRepository.findById(productId);
        if (product.isPresent()) {
            customerRepository.deleteById(productId);
        }
    }
}
